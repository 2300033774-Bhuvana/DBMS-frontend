// src/components/ShelterLocator.jsx
import React, { useState } from 'react';
import './ShelterLocator.css';

const ShelterLocator = () => {
  const [shelters, setShelters] = useState([
    { id: 1, name: "Community Center", address: "123 Main St", distance: "0.5 km", capacity: "120 people" },
    { id: 2, name: "High School Gym", address: "456 Oak Ave", distance: "1.2 km", capacity: "300 people" },
    { id: 3, name: "Red Cross Shelter", address: "789 Pine Rd", distance: "2.0 km", capacity: "200 people" }
  ]);

  const [showMap, setShowMap] = useState(false);

  return (
    <div className="shelter-container">
      <h2>🏠 Nearest Shelters</h2>
      <button 
        className="map-toggle-btn"
        onClick={() => setShowMap(!showMap)}
      >
        {showMap ? 'Hide Map View' : 'Show Map View'}
      </button>

      {showMap ? (
        <div className="map-placeholder">
          {/* In a real app, you would integrate with Google Maps or similar */}
          <p>Map would display here with shelter locations</p>
        </div>
      ) : (
        <div className="shelter-list">
          {shelters.map(shelter => (
            <div key={shelter.id} className="shelter-card">
              <h3>{shelter.name}</h3>
              <p>📍 {shelter.address}</p>
              <p>🚶‍♂️ {shelter.distance} away</p>
              <p>👥 Capacity: {shelter.capacity}</p>
              <button className="directions-btn">Get Directions</button>
            </div>
          ))}
        </div>
      )}

      <div className="shelter-actions">
        <button className="refresh-btn">Refresh Locations</button>
        <button className="add-shelter-btn">Report New Shelter</button>
      </div>
    </div>
  );
};

export default ShelterLocator;