// src/pages/Home.jsx
import React from 'react';
import './Home.css';
import floodImg from '../assets/flood.jpg';
import fireImg from '../assets/fire.jpg';
import earthquakeImg from '../assets/earthquake.jpg';
import cycloneImg from '../assets/cyclone.jpg';

function Home() {
  return (
    <div className="home-container">
      <div className="home-hero">
        <h1>🚨 Disaster Management System</h1>
        <p>Your centralized platform for emergency response coordination.</p>
        <div className="home-buttons">
          <a href="/report" className="home-btn">Report Incident</a>
          <a href="/resources" className="home-btn outline">Allocate Resources</a>
        </div>
      </div>

      <div className="home-gallery">
        <img src={floodImg} alt="Flood" />
        <img src={fireImg} alt="Fire" />
        <img src={earthquakeImg} alt="Earthquake" />
        <img src={cycloneImg} alt="Cyclone" />
      </div>

      <div className="home-contacts">
        <h2>📞 Emergency Contact Numbers</h2>
        <ul>
          <li>🚓 Police: <strong>100</strong></li>
          <li>🚑 Ambulance: <strong>102</strong></li>
          <li>🔥 Fire: <strong>101</strong></li>
          <li>🆘 National Disaster Helpline: <strong>108</strong></li>
          <li>📱 Disaster Support WhatsApp: <strong>+91-XXXXXXXXXX</strong></li>
        </ul>
      </div>
    </div>
  );
}

export default Home;
