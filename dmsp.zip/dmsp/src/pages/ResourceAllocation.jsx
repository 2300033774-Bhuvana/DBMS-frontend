import React, { useState } from 'react';
import axios from 'axios';
import './ResourceAllocation.css';

function ResourceAllocation() {
  const [formData, setFormData] = useState({
    name: '',
    type: '',
    quantity: '',
    location: '',
  });

  const handleChange = (e) => {
    setFormData(prev => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    axios.post('http://localhost:8080/api/resources', formData)
      .then(() => {
        alert('Resource allocated successfully');
        setFormData({ name: '', type: '', quantity: '', location: '' });
      })
      .catch(err => console.error('Error adding resource:', err));
  };

  return (
    <div className="allocation">
      <h2>Allocate a New Resource</h2>
      <form onSubmit={handleSubmit}>
        <input name="name" value={formData.name} onChange={handleChange} placeholder="Resource Name" required />
        <input name="type" value={formData.type} onChange={handleChange} placeholder="Type (e.g., Food, Water)" required />
        <input name="quantity" value={formData.quantity} onChange={handleChange} placeholder="Quantity" required />
        <input name="location" value={formData.location} onChange={handleChange} placeholder="Location" required />
        <button type="submit">Allocate</button>
      </form>
    </div>
  );
}

export default ResourceAllocation;
