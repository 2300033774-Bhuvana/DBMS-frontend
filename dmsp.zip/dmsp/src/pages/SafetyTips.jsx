// src/components/SafetyTips.jsx
import React, { useState } from 'react';
import './SafetyTips.css';

const SafetyTips = () => {
  const [activeCategory, setActiveCategory] = useState('general');

  const tipsData = {
    general: [
      "Always have an emergency kit ready with essentials",
      "Identify safe spots in your home for each type of disaster",
      "Create and practice a family emergency plan"
    ],
    flood: [
      "Move to higher ground immediately",
      "Avoid walking or driving through flood waters",
      "Turn off electricity at the main breaker"
    ],
    earthquake: [
      "Drop, Cover, and Hold On during shaking",
      "Stay indoors until shaking stops",
      "Stay away from windows and heavy objects"
    ],
    fire: [
      "Check smoke alarms regularly",
      "Have an escape plan with two ways out",
      "Stop, Drop, and Roll if clothes catch fire"
    ]
  };

  return (
    <div className="safety-tips-container">
      <h2>🛡️ Safety Tips</h2>
      
      <div className="category-tabs">
        <button 
          className={activeCategory === 'general' ? 'active' : ''}
          onClick={() => setActiveCategory('general')}
        >
          General
        </button>
        <button 
          className={activeCategory === 'flood' ? 'active' : ''}
          onClick={() => setActiveCategory('flood')}
        >
          Flood
        </button>
        <button 
          className={activeCategory === 'earthquake' ? 'active' : ''}
          onClick={() => setActiveCategory('earthquake')}
        >
          Earthquake
        </button>
        <button 
          className={activeCategory === 'fire' ? 'active' : ''}
          onClick={() => setActiveCategory('fire')}
        >
          Fire
        </button>
      </div>
      
      <div className="tips-list">
        <h3>{activeCategory.charAt(0).toUpperCase() + activeCategory.slice(1)} Safety Tips</h3>
        <ul>
          {tipsData[activeCategory].map((tip, index) => (
            <li key={index}>{tip}</li>
          ))}
        </ul>
      </div>
      
      <div className="emergency-numbers">
        <h3>Remember these emergency numbers:</h3>
        <p>🚓 Police: 100 | 🚑 Ambulance: 102 | 🔥 Fire: 101</p>
      </div>
    </div>
  );
};

export default SafetyTips;