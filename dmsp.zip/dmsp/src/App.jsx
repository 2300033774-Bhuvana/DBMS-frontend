import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navigation from './components/Navigation';
import Home from './pages/Home';
import ReportIncident from './pages/ReportIncident';
import TrackRelief from './pages/TrackRelief';
import ResourceAllocation from './pages/ResourceAllocation';
import './App.css';

function App() {
  return (
    <Router>
      <Navigation />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/report" element={<ReportIncident />} />
        <Route path="/track" element={<TrackRelief />} />
        <Route path="/resources" element={<ResourceAllocation />} />
      </Routes>
    </Router>
  );
}

export default App;