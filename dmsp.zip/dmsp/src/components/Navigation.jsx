import React from 'react';
import { Link } from 'react-router-dom';
import './Navigation.css';

function Navigation() {
  return (
    <nav className="nav">
      <h2>Disaster Management</h2>
      <div className="nav-links">
        <Link to="/">Home</Link>
        <Link to="/report">Report Incident</Link>
        <Link to="/track">Track Relief</Link>
        <Link to="/resources">Resource Allocation</Link>
      </div>
    </nav>
  );
}

export default Navigation;
